/**
 * dsh-ultra effort plugin: the `/effort` command grades reasoning effort and
 * toggles automatic orchestration, persisted through settings.
 *
 * This is a thin semantic layer per ADR-001: it writes the resolved reasoning
 * effort into the default model selection (`ctx.agentDefaultModel`) so the
 * agent loop applies it without any adapter or loop patch, and it records the
 * selected level under its own settings namespace for the orchestration layer
 * (`dsh-ultra-orchestrator`) to consume.
 *
 * @module dsh-ultra
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { type UltraEffortLevel, type UltraEffortMap } from './effort.ts';
export declare const name = "ultra-effort";
export declare const inject: string[];
/** Settings payload recorded under the `ultra-effort` settings namespace. */
export interface UltraEffortSettings {
    /** The currently selected ultra effort level. */
    level: UltraEffortLevel;
}
/** Deployment policy for the effort command. */
export interface Config {
    /** Level → adapter reasoning effort mapping (defaults: DeepSeek V4). */
    effortMap?: UltraEffortMap;
    /** Levels that enable automatic orchestration. */
    autoOrchestrateLevels?: UltraEffortLevel[];
}
/** Schemastery configuration for the effort plugin. */
export declare const Config: z<Config>;
/**
 * Mount the effort plugin: install the settings section and register the
 * `/effort` command.
 * @param ctx - the Cordis context.
 * @param config - deployment effort mapping and orchestration levels.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map